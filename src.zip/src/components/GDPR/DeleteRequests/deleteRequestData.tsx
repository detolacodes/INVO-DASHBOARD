const date = new Date()
const day = date.getDate()

const DeleteData = [

{
	id:'1',
	name:'Rampage',
	message: 'please delete my data (Player data will be deleted in accordance with GDPR rules)',
	requestType:'',
	date:date.toDateString(),
},

{
	id:'2',
	name:'FlyLady2202',
	message: 'please delete my data (Player data will be deleted in accordance with GDPR rules)',
	requestType:'',
	date:date.toDateString(),
},

{
	id:'3',
	name:'The Rock29',
	message: 'please delete my data (Player data will be deleted in accordance with GDPR rules)',
	requestType:'',
	date:date.toDateString(),
},

{
	id:'4',
	name:'Rampage-002',
	message: 'please delete my data (Player data will be deleted in accordance with GDPR rules)',
	requestType:'',
	date:date.toDateString(),
},

];

export default DeleteData
