const date = new Date()

const playerData = [


	{
		id:'1',
		name:'Peter Pan, me',
		notiLevel:'support',
		notiAmount: '(4)',
		message:'Hello – Trip home from Colombo has been arranged, then Jenna will come get me from Stockholm.',
		date:date.toDateString(),
		// status:,
	},

	{
		id:'2',
		name:'Peter Pan, me',
		notiLevel:'warning',
		notiAmount: '(4)',
		message:'Since you asked and i am inconceivably bored at the train station. Alright thanks.',
		date:date.toDateString(),
		// status:,
	},

	{
		id:'3',
		name:'Peter Pan, me',
		notiLevel:'general questions',
		notiAmount: '(4)',
		message:'Hello – Trip home from Colombo has been arranged, then Jenna will come get me from Stockholm.',
		date:date.toDateString(),
		// status:,
	},

	{
		id:'4',
		name:'Peter Pan, me',
		notiLevel:'transfer errors',
		notiAmount: '(4)',
		message:'Hello – Trip home from Colombo has been arranged, then Jenna will come get me from Stockholm.',
		date:date.toDateString(),
		// status:,
	},

	{
		id:'5',
		name:'Peter Pan, me',
		notiLevel:'questions',
		notiAmount: '(4)',
		message:'Hello – Trip home from Colombo has been arranged, then Jenna will come get me from Stockholm.',
		date:date.toDateString(),
		// status:,
	},

]

export default playerData