import React, { useState } from 'react';

const GDPRDelete = () =>{


	return(
		<>

			<div>
				
			</div>


		</>
	)

}

export default GDPRDelete