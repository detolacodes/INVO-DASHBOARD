import {useState} from 'react'


const OrderBookActivities = () =>{

	return(

		<>

			<div className='flex-h-new1 w-100 flex-1 h-100'>
				<div className='w-100 flex-1 h-100'>
					<iframe src='orderbooktable.html' className='frame' width='100%' height='100%' ></iframe>
				</div>
			</div>

		</>
	)

}

export default OrderBookActivities
