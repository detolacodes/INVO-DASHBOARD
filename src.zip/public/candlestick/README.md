jqCandlestick
=============

jQuery plugin for creating line, bar and candlestick charts.

Supported browsers
------------------
Should work in all browsers that support the canvas element (tested in newest
versions of Chrome, Firefox and Internet Explorer).

Support for Internet Explorer 8 and below should be possible using polyfill and an
older version of jQuery. See https://code.google.com/p/explorercanvas for polyfill.
